function out = isskew(A)
    out = issymmetric(A,'skew') ;
end