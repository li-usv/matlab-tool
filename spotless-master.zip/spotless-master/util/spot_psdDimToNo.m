function n = spot_psdDimToNo(d)
    n=(d+1).*d/2;
end