function x=vertcat(varargin)
% See private methods in msspoly.
x = cat(1,varargin{:});
end

