function q=ctranspose(p)
q = conj(transpose(p));
end
