function x=horzcat(varargin)
% See private methods in msspoly.
x = cat(2,varargin{:});
end
