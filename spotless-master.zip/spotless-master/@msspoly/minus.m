function p=minus(p1,p2)
p = p1+uminus(p2);
end
