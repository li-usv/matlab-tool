function y=isempty(p)
y = prod(p.dim) == 0;
end
