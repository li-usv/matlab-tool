function n = nnz(p)
    n = length(find(p));
end