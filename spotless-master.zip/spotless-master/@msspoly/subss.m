function q = subss(p,a,b)
    q = subs(p,a,b);
end
    