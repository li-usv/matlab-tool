function y=isscalar(p)
y = spot_hasSize(p,[1 1]);
end
