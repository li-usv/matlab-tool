function q = flipud(p)
    q = fliplr(p')';
end