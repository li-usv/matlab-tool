function x=variables(pr)
% function x=variables(pr)
%
% x is the free msspoly of all variables registered with pr

x=pr.v;